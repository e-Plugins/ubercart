<?php
namespace Drupal\uc_digiwallet\Plugin\Ubercart\PaymentMethod;

use Drupal\uc_payment\PaymentMethodPluginBase;

/**
 * Defines the Digiwallet Express Checkout payment method.
 */
abstract class DigiwalletPaymentMethodPluginBase extends PaymentMethodPluginBase
{
}
