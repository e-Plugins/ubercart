<?php
namespace Drupal\uc_targetpay\Plugin\Ubercart\PaymentMethod;

use Drupal\uc_payment\PaymentMethodPluginBase;

/**
 * Defines the Targetpay Express Checkout payment method.
 */
abstract class TargetpayPaymentMethodPluginBase extends PaymentMethodPluginBase
{
}
